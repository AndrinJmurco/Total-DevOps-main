# Install Agro CLI using Kubernetes
```
kubectl create namespace argo
kubectl apply -n argo -f https://github.com/argoproj/argo-workflows/re
```
