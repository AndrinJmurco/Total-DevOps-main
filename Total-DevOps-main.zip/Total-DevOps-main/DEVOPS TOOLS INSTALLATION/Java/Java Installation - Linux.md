# Java Installation in RHEL
## Login as a root user
```
sudo su -
```
## Install JRE 1.8
```
yum install java-1.8.0-openjdk -y
java -version 
```
## Install JDK 1.8
```
yum install java-1.8.0-openjdk-devel -y
javac -version
```
## Install JRE 11 
```
yum install java-11-openjdk -y
java -version 
```
## Install JDK 11
```
yum install java-11-openjdk-devel -y
javac -version  
```
#  Java Installation  in Ubuntu
## Login as a root user
```
sudo su -
```
