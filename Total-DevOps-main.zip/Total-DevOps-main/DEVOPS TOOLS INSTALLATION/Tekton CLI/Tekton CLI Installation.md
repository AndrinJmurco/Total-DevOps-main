# Install Tekton CLI in MAC Book 
 
Tekton provides a CLI, tkn, for easier interaction with Tekton components.

 

a) Tekton CLI Installation in MAC Book

 

Open the terminal and execute the below commands
```
#brew tap tektoncd/tools

#brew install tektoncd/tools/tektoncd-cli
```
