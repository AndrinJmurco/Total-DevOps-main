In Linux the shell (or terminal) is the lifeline of the developer, and of any power user. Things which can be done onthe GUI (by clicking on different buttons), 
can be done much more efficiently on the terminal by using commands. Maybe one can not remember all the commands, but with regular usage one can easily remember 
the most useful ones.The following guide will introduce you to a minimal set of basic commands required to use your Linux computerefficiently.



## 1. Terminal emulators

